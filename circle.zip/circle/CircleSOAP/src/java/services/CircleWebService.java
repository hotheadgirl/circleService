/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Yoga
 */
@WebService(serviceName = "CircleWebService")
public class CircleWebService {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "area")
    public double area(@WebParam(name = "r") double r) {
        //TODO write your implementation code here:
        return 3.14*r*r;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "circle")
    public double circle(@WebParam(name = "r") double r) {
        //TODO write your implementation code here:
        return 2.0*3.14*r;
    }


}
