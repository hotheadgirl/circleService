/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package circcleclient;

/**
 *
 * @author Yoga
 */
public class CirccleClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("area is "+area(2));
        System.out.println("circumference is "+circle(3));
    }

    private static double area(double r) {
        serviceClient.CircleWebService_Service service = new serviceClient.CircleWebService_Service();
        serviceClient.CircleWebService port = service.getCircleWebServicePort();
        return port.area(r);
    }

    private static double circle(double r) {
        serviceClient.CircleWebService_Service service = new serviceClient.CircleWebService_Service();
        serviceClient.CircleWebService port = service.getCircleWebServicePort();
        return port.circle(r);
    }
    
}
